﻿Imports System.Drawing

Namespace GougeChecker3D

    Public Structure PointD
        Public X As Double
        Public Y As Double
        Public Sub New(x As Double, y As Double)
            Me.X = x
            Me.Y = y
        End Sub
    End Structure

    Public MustInherit Class Entity
        Public MustOverride Sub Draw(g As Graphics, zoom As Single, panOffset As PointD)
        Public MustOverride Function GetBounds() As (Min As PointD, Max As PointD)
    End Class

    Public Class LineEntity
        Inherits Entity
        Public StartPoint As PointD
        Public EndPoint As PointD
        Public Sub New(startPt As PointD, endPt As PointD)
            StartPoint = startPt
            EndPoint = endPt
        End Sub
        Public Overrides Sub Draw(g As Graphics, zoom As Single, panOffset As PointD)
            g.DrawLine(Pens.Black, CSng((StartPoint.X + panOffset.X) * zoom), CSng((StartPoint.Y + panOffset.Y) * zoom),
                       CSng((EndPoint.X + panOffset.X) * zoom), CSng((EndPoint.Y + panOffset.Y) * zoom))
        End Sub
        Public Overrides Function GetBounds() As (PointD, PointD)
            Dim minPt As New PointD(Math.Min(StartPoint.X, EndPoint.X), Math.Min(StartPoint.Y, EndPoint.Y))
            Dim maxPt As New PointD(Math.Max(StartPoint.X, EndPoint.X), Math.Max(StartPoint.Y, EndPoint.Y))
            Return (minPt, maxPt)
        End Function
    End Class

    Public Class CircleEntity
        Inherits Entity
        Public Center As PointD
        Public Radius As Double
        Public Sub New(center As PointD, radius As Double)
            Me.Center = center
            Me.Radius = radius
        End Sub
        Public Overrides Sub Draw(g As Graphics, zoom As Single, panOffset As PointD)
            g.DrawEllipse(Pens.Blue,
                          CSng((Center.X - Radius + panOffset.X) * zoom),
                          CSng((Center.Y - Radius + panOffset.Y) * zoom),
                          CSng(Radius * 2 * zoom),
                          CSng(Radius * 2 * zoom))
        End Sub
        Public Overrides Function GetBounds() As (PointD, PointD)
            Return (New PointD(Center.X - Radius, Center.Y - Radius),
                    New PointD(Center.X + Radius, Center.Y + Radius))
        End Function
    End Class

    Public Class ArcEntity
        Inherits Entity
        Public Center As PointD
        Public Radius As Double
        Public StartAngle As Double
        Public EndAngle As Double
        Public Sub New(center As PointD, radius As Double, startAngle As Double, endAngle As Double)
            Me.Center = center
            Me.Radius = radius
            Me.StartAngle = startAngle
            Me.EndAngle = endAngle
        End Sub
        Public Overrides Sub Draw(g As Graphics, zoom As Single, panOffset As PointD)
            Dim rect = New RectangleF(CSng((Center.X - Radius + panOffset.X) * zoom),
                                      CSng((Center.Y - Radius + panOffset.Y) * zoom),
                                      CSng(Radius * 2 * zoom),
                                      CSng(Radius * 2 * zoom))
            g.DrawArc(Pens.Green, rect, CSng(StartAngle), CSng(EndAngle - StartAngle))
        End Sub
        Public Overrides Function GetBounds() As (PointD, PointD)
            Return (New PointD(Center.X - Radius, Center.Y - Radius),
                    New PointD(Center.X + Radius, Center.Y + Radius))
        End Function
    End Class

    Public Class EllipseEntity
        Inherits Entity
        Public Center As PointD
        Public MajorAxis As Double
        Public MinorAxis As Double
        Public Sub New(center As PointD, major As Double, minor As Double)
            Me.Center = center
            Me.MajorAxis = major
            Me.MinorAxis = minor
        End Sub
        Public Overrides Sub Draw(g As Graphics, zoom As Single, panOffset As PointD)
            g.DrawEllipse(Pens.Purple,
                          CSng((Center.X - MajorAxis + panOffset.X) * zoom),
                          CSng((Center.Y - MinorAxis + panOffset.Y) * zoom),
                          CSng(MajorAxis * 2 * zoom),
                          CSng(MinorAxis * 2 * zoom))
        End Sub
        Public Overrides Function GetBounds() As (PointD, PointD)
            Return (New PointD(Center.X - MajorAxis, Center.Y - MinorAxis),
                    New PointD(Center.X + MajorAxis, Center.Y + MinorAxis))
        End Function
    End Class

    Public Class PolylineEntity
        Inherits Entity
        Public Points As List(Of PointD)
        Public Sub New(points As List(Of PointD))
            Me.Points = points
        End Sub
        Public Overrides Sub Draw(g As Graphics, zoom As Single, panOffset As PointD)
            For i = 0 To Points.Count - 2
                g.DrawLine(Pens.Orange,
                           CSng((Points(i).X + panOffset.X) * zoom),
                           CSng((Points(i).Y + panOffset.Y) * zoom),
                           CSng((Points(i + 1).X + panOffset.X) * zoom),
                           CSng((Points(i + 1).Y + panOffset.Y) * zoom))
            Next
        End Sub
        Public Overrides Function GetBounds() As (PointD, PointD)
            Dim minX = Points.Min(Function(p) p.X)
            Dim minY = Points.Min(Function(p) p.Y)
            Dim maxX = Points.Max(Function(p) p.X)
            Dim maxY = Points.Max(Function(p) p.Y)
            Return (New PointD(minX, minY), New PointD(maxX, maxY))
        End Function
    End Class

    Public Class LwPolylineEntity
        Inherits PolylineEntity
        Public Sub New(points As List(Of PointD))
            MyBase.New(points)
        End Sub
    End Class

    Public Class SplineEntity
        Inherits Entity
        Public Points As List(Of PointD)
        Public Sub New(points As List(Of PointD))
            Me.Points = points
        End Sub
        Public Overrides Sub Draw(g As Graphics, zoom As Single, panOffset As PointD)
            If Points.Count > 1 Then
                For i = 0 To Points.Count - 2
                    g.DrawLine(Pens.Brown,
                               CSng((Points(i).X + panOffset.X) * zoom),
                               CSng((Points(i).Y + panOffset.Y) * zoom),
                               CSng((Points(i + 1).X + panOffset.X) * zoom),
                               CSng((Points(i + 1).Y + panOffset.Y) * zoom))
                Next
            End If
        End Sub
        Public Overrides Function GetBounds() As (PointD, PointD)
            Dim minX = Points.Min(Function(p) p.X)
            Dim minY = Points.Min(Function(p) p.Y)
            Dim maxX = Points.Max(Function(p) p.X)
            Dim maxY = Points.Max(Function(p) p.Y)
            Return (New PointD(minX, minY), New PointD(maxX, maxY))
        End Function
    End Class

    Public Class TextEntity
        Inherits Entity
        Public Position As PointD
        Public Text As String
        Public Height As Double
        Public Sub New(pos As PointD, txt As String, height As Double)
            Me.Position = pos
            Me.Text = txt
            Me.Height = height
        End Sub
        Public Overrides Sub Draw(g As Graphics, zoom As Single, panOffset As PointD)
            g.DrawString(Text, SystemFonts.DefaultFont, Brushes.Black,
                         CSng((Position.X + panOffset.X) * zoom),
                         CSng((Position.Y + panOffset.Y) * zoom))
        End Sub
        Public Overrides Function GetBounds() As (PointD, PointD)
            Return (Position, Position) ' Simplified
        End Function
    End Class

    Public Class DimensionEntity
        Inherits LineEntity
        Public Sub New(startPt As PointD, endPt As PointD)
            MyBase.New(startPt, endPt)
        End Sub
    End Class

End Namespace
