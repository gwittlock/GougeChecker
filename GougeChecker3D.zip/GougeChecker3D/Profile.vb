﻿Imports System.Collections.Generic

Namespace GougeChecker3D

    Public Class Profile
        Public Property Entities As List(Of Entity)

        Public Sub New()
            Entities = New List(Of Entity)()
        End Sub
    End Class

End Namespace
