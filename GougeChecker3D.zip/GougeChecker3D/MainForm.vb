﻿Imports GougeChecker3D
Imports GougeChecker3D.GougeChecker3D
Imports System.Drawing
Imports System.Windows.Forms

Public Class MainForm
    Inherits Form

    Private WithEvents btnLoadDXF As New Button()
    Private pnlCanvas As New Panel()
    Private profile As ProfileReader
    Private zoom As Single = 1.0F
    Private panOffset As PointD = New PointD(0, 0)

    Public Sub New()
        MyBase.New()
        Me.Text = "GougeChecker3D"
        Me.Width = 1000
        Me.Height = 700

        ' Panel setup
        pnlCanvas.Dock = DockStyle.Fill
        pnlCanvas.BackColor = Color.White
        Me.Controls.Add(pnlCanvas)

        ' Button setup
        btnLoadDXF.Text = "Load DXF"
        btnLoadDXF.Dock = DockStyle.Top
        Me.Controls.Add(btnLoadDXF)

        ' Enable double-buffering for smooth drawing
        pnlCanvas.DoubleBuffered = True

        ' Mouse wheel for zoom
        AddHandler pnlCanvas.MouseWheel, AddressOf pnlCanvas_MouseWheel

        ' Initial empty profile
        profile = New ProfileReader()
    End Sub

    Private Sub btnLoadDXF_Click(sender As Object, e As EventArgs) Handles btnLoadDXF.Click
        Using dlg As New OpenFileDialog()
            dlg.Filter = "DXF Files|*.dxf"
            If dlg.ShowDialog() = DialogResult.OK Then
                profile.LoadFromFile(dlg.FileName)
                pnlCanvas.Invalidate()
            End If
        End Using
    End Sub

    Private Sub pnlCanvas_Paint(sender As Object, e As PaintEventArgs) Handles pnlCanvas.Paint
        If profile Is Nothing OrElse profile.Entities.Count = 0 Then Return

        Dim g As Graphics = e.Graphics
        g.SmoothingMode = Drawing2D.SmoothingMode.AntiAlias

        ' Compute scaling
        Dim boundsMin = profile.BoundsMin
        Dim boundsMax = profile.BoundsMax
        Dim widthScale = pnlCanvas.Width / (boundsMax.X - boundsMin.X)
        Dim heightScale = pnlCanvas.Height / (boundsMax.Y - boundsMin.Y)
        Dim scale As Single = CSng(Math.Min(widthScale, heightScale) * zoom)

        ' Draw each entity
        For Each ent In profile.Entities
            Select Case ent
                Case TryCast(ent, LineEntity)
                    Dim le = CType(ent, LineEntity)
                    g.DrawLine(Pens.Black, Transform(le.Start, boundsMin, scale), Transform(le.End, boundsMin, scale))
                Case TryCast(ent, CircleEntity)
                    Dim ce = CType(ent, CircleEntity)
                    Dim center = Transform(ce.Center, boundsMin, scale)
                    Dim r = CSng(ce.Radius * scale)
                    g.DrawEllipse(Pens.Blue, center.X - r, center.Y - r, r * 2, r * 2)
                Case TryCast(ent, ArcEntity)
                    Dim ae = CType(ent, ArcEntity)
                    Dim center = Transform(ae.Center, boundsMin, scale)
                    Dim r = CSng(ae.Radius * scale)
                    g.DrawArc(Pens.Green, center.X - r, center.Y - r, r * 2, r * 2, CSng(-ae.StartAngle), CSng(ae.EndAngle - ae.StartAngle))
                Case TryCast(ent, PolylineEntity)
                    Dim pe = CType(ent, PolylineEntity)
                    If pe.Points.Count > 1 Then
                        For i = 0 To pe.Points.Count - 2
                            g.DrawLine(Pens.Orange, Transform(pe.Points(i), boundsMin, scale), Transform(pe.Points(i + 1), boundsMin, scale))
                        Next
                    End If
                Case TryCast(ent, LwPolylineEntity)
                    Dim pe = CType(ent, LwPolylineEntity)
                    If pe.Points.Count > 1 Then
                        For i = 0 To pe.Points.Count - 2
                            g.DrawLine(Pens.Purple, Transform(pe.Points(i), boundsMin, scale), Transform(pe.Points(i + 1), boundsMin, scale))
                        Next
                    End If
                Case TryCast(ent, EllipseEntity)
                    Dim ee = CType(ent, EllipseEntity)
                    Dim center = Transform(ee.Center, boundsMin, scale)
                    Dim major = CSng(ee.MajorAxis * scale)
                    Dim minor = CSng(ee.MinorAxis * scale)
                    g.DrawEllipse(Pens.Brown, center.X - major, center.Y - minor, major * 2, minor * 2)
                Case TryCast(ent, SplineEntity)
                    Dim se = CType(ent, SplineEntity)
                    If se.Points.Count > 1 Then
                        For i = 0 To se.Points.Count - 2
                            g.DrawLine(Pens.CadetBlue, Transform(se.Points(i), boundsMin, scale), Transform(se.Points(i + 1), boundsMin, scale))
                        Next
                    End If
                Case TryCast(ent, TextEntity)
                    Dim te = CType(ent, TextEntity)
                    Dim pos = Transform(te.Position, boundsMin, scale)
                    g.DrawString(te.Text, SystemFonts.DefaultFont, Brushes.Black, pos.X, pos.Y)
                Case TryCast(ent, DimensionEntity)
                    Dim de = CType(ent, DimensionEntity)
                    g.DrawLine(Pens.DarkRed, Transform(de.Start, boundsMin, scale), Transform(de.End, boundsMin, scale))
            End Select
        Next
    End Sub

    Private Function Transform(pt As PointD, min As PointD, scale As Single) As PointF
        Dim x = CSng((pt.X - min.X + panOffset.X) * scale)
        Dim y = CSng((pt.Y - min.Y + panOffset.Y) * scale)
        ' Flip Y to match typical graphics coordinates
        Return New PointF(x, pnlCanvas.Height - y)
    End Function

    Private Sub pnlCanvas_MouseWheel(sender As Object, e As MouseEventArgs)
        zoom += e.Delta / 1200.0F
        If zoom < 0.1F Then zoom = 0.1F
        pnlCanvas.Invalidate()
    End Sub

End Class
