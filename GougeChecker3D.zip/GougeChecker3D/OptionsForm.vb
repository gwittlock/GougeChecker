﻿Imports System.Windows.Forms

Public Class OptionsForm
    Inherits Form

    Public Sub New()
        Me.Text = "Options"
        Me.Width = 400
        Me.Height = 200
    End Sub
End Class
