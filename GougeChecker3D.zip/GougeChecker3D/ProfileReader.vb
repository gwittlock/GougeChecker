﻿Imports System.IO
Imports System.Globalization

Namespace GougeChecker3D

    Public Class ProfileReader
        Public Entities As New List(Of Entity)

        Public Sub New()
        End Sub

        ' Compute bounds for all entities
        Public ReadOnly Property BoundsMin As PointD
            Get
                If Entities.Count = 0 Then Return New PointD(0, 0)
                Dim minX = Entities.Min(Function(e) e.GetBounds().Min.X)
                Dim minY = Entities.Min(Function(e) e.GetBounds().Min.Y)
                Return New PointD(minX, minY)
            End Get
        End Property

        Public ReadOnly Property BoundsMax As PointD
            Get
                If Entities.Count = 0 Then Return New PointD(0, 0)
                Dim maxX = Entities.Max(Function(e) e.GetBounds().Max.X)
                Dim maxY = Entities.Max(Function(e) e.GetBounds().Max.Y)
                Return New PointD(maxX, maxY)
            End Get
        End Property

        ' Minimal DXF parser
        Public Sub LoadFromFile(filePath As String)
            If Not File.Exists(filePath) Then Throw New FileNotFoundException("DXF file not found", filePath)

            Dim lines() As String = File.ReadAllLines(filePath)
            Dim i As Integer = 0
            While i < lines.Length
                Dim code As String = lines(i).Trim()
                Dim value As String = If(i + 1 < lines.Length, lines(i + 1).Trim(), "")
                i += 2

                Select Case code
                    Case "0" ' Entity type
                        Select Case value
                            Case "LINE"
                                Dim line As New LineEntity()
                                ' Read start and end points
                                While i < lines.Length
                                    Dim c = lines(i).Trim()
                                    Dim v = If(i + 1 < lines.Length, lines(i + 1).Trim(), "")
                                    i += 2
                                    Select Case c
                                        Case "10" : line.Start.X = Double.Parse(v, CultureInfo.InvariantCulture)
                                        Case "20" : line.Start.Y = Double.Parse(v, CultureInfo.InvariantCulture)
                                        Case "11" : line.End.X = Double.Parse(v, CultureInfo.InvariantCulture)
                                        Case "21" : line.End.Y = Double.Parse(v, CultureInfo.InvariantCulture)
                                        Case "0" : i -= 2 : Exit While
                                    End Select
                                End While
                                Entities.Add(line)

                            Case "CIRCLE"
                                Dim c As New CircleEntity()
                                While i < lines.Length
                                    Dim code2 = lines(i).Trim()
                                    Dim val2 = If(i + 1 < lines.Length, lines(i + 1).Trim(), "")
                                    i += 2
                                    Select Case code2
                                        Case "10" : c.Center.X = Double.Parse(val2, CultureInfo.InvariantCulture)
                                        Case "20" : c.Center.Y = Double.Parse(val2, CultureInfo.InvariantCulture)
                                        Case "40" : c.Radius = Double.Parse(val2, CultureInfo.InvariantCulture)
                                        Case "0" : i -= 2 : Exit While
                                    End Select
                                End While
                                Entities.Add(c)

                            Case "ARC"
                                Dim a As New ArcEntity()
                                While i < lines.Length
                                    Dim code2 = lines(i).Trim()
                                    Dim val2 = If(i + 1 < lines.Length, lines(i + 1).Trim(), "")
                                    i += 2
                                    Select Case code2
                                        Case "10" : a.Center.X = Double.Parse(val2, CultureInfo.InvariantCulture)
                                        Case "20" : a.Center.Y = Double.Parse(val2, CultureInfo.InvariantCulture)
                                        Case "40" : a.Radius = Double.Parse(val2, CultureInfo.InvariantCulture)
                                        Case "50" : a.StartAngle = Double.Parse(val2, CultureInfo.InvariantCulture)
                                        Case "51" : a.EndAngle = Double.Parse(val2, CultureInfo.InvariantCulture)
                                        Case "0" : i -= 2 : Exit While
                                    End Select
                                End While
                                Entities.Add(a)

                            Case "LWPOLYLINE", "POLYLINE"
                                Dim pl As New PolylineEntity()
                                Dim pts As New List(Of PointD)
                                While i < lines.Length
                                    Dim c = lines(i).Trim()
                                    Dim v = If(i + 1 < lines.Length, lines(i + 1).Trim(), "")
                                    i += 2
                                    Select Case c
                                        Case "10" : pts.Add(New PointD(Double.Parse(v, CultureInfo.InvariantCulture), 0))
                                        Case "20"
                                            If pts.Count > 0 Then pts(pts.Count - 1).Y = Double.Parse(v, CultureInfo.InvariantCulture)
                                        Case "0" : i -= 2 : Exit While
                                    End Select
                                End While
                                pl.Points = pts
                                Entities.Add(pl)

                            Case "ELLIPSE"
                                Dim e As New EllipseEntity()
                                While i < lines.Length
                                    Dim c = lines(i).Trim()
                                    Dim v = If(i + 1 < lines.Length, lines(i + 1).Trim(), "")
                                    i += 2
                                    Select Case c
                                        Case "10" : e.Center.X = Double.Parse(v, CultureInfo.InvariantCulture)
                                        Case "20" : e.Center.Y = Double.Parse(v, CultureInfo.InvariantCulture)
                                        Case "11" : e.MajorAxis = Double.Parse(v, CultureInfo.InvariantCulture)
                                        Case "21" : e.MinorAxis = Double.Parse(v, CultureInfo.InvariantCulture)
                                        Case "0" : i -= 2 : Exit While
                                    End Select
                                End While
                                Entities.Add(e)

                            Case "SPLINE"
                                Dim s As New SplineEntity()
                                s.Points = New List(Of PointD)() ' Minimal parsing, can be improved
                                Entities.Add(s)

                            Case "TEXT"
                                Dim t As New TextEntity()
                                While i < lines.Length
                                    Dim c = lines(i).Trim()
                                    Dim v = If(i + 1 < lines.Length, lines(i + 1).Trim(), "")
                                    i += 2
                                    Select Case c
                                        Case "10" : t.Position.X = Double.Parse(v, CultureInfo.InvariantCulture)
                                        Case "20" : t.Position.Y = Double.Parse(v, CultureInfo.InvariantCulture)
                                        Case "1" : t.Text = v
                                        Case "40" : t.Height = Double.Parse(v, CultureInfo.InvariantCulture)
                                        Case "0" : i -= 2 : Exit While
                                    End Select
                                End While
                                Entities.Add(t)

                            Case "DIMENSION"
                                Dim d As New DimensionEntity()
                                While i < lines.Length
                                    Dim c = lines(i).Trim()
                                    Dim v = If(i + 1 < lines.Length, lines(i + 1).Trim(), "")
                                    i += 2
                                    Select Case c
                                        Case "10" : d.Start.X = Double.Parse(v, CultureInfo.InvariantCulture)
                                        Case "20" : d.Start.Y = Double.Parse(v, CultureInfo.InvariantCulture)
                                        Case "11" : d.End.X = Double.Parse(v, CultureInfo.InvariantCulture)
                                        Case "21" : d.End.Y = Double.Parse(v, CultureInfo.InvariantCulture)
                                        Case "0" : i -= 2 : Exit While
                                    End Select
                                End While
                                Entities.Add(d)

                        End Select
                End Select
            End While
        End Sub

    End Class

End Namespace
